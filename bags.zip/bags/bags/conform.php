<?php
echo "<script>alert('Okkk google')</script>";
?>

