<?php

echo' <link href="assets/css/color.css" rel="stylesheet">
        <link href="assets/css/preloader.css" rel="stylesheet">
        <link href="assets/css/slider.css" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/prettyPhoto.css" rel="stylesheet">
        <link href="css/price-range.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">
        <link href="css/main.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">
        <link href="css/comment.css" rel="stylesheet">
        <link href="css/form_contact.css" rel="stylesheet">
        <link href="css/update.css" rel="stylesheet">
        <link href="assets/css/footer.css" rel="stylesheet">
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
        <link href="assets/css/game.css" rel="stylesheet">
        <link href="assets/css/popup.css" rel="stylesheet">
        <link href="assets/css/animate_product.css" rel="stylesheet">
        <link href="assets/css/product-detail.css" rel="stylesheet">

        ';
?>