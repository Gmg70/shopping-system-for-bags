<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="shortcut icon" href="images/icon.png" type="image/x-icon"/>
        <title>Modern Bag System | rules</title>
        <?php
        include 'cssfile.php';
        ?>
    </head>
    <body>
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
        <div id="" class="">
            <div class="popup">
                <h2>Terms and Use</h2>
                <img border="0" src="images/logo1.gif" width="200" height="40" alt="logo">
                <br>
                
                <div style="overflow:auto;" class="content">

                    <table border="0" width="100%" cellspacing="0" id="table1">
                        <tbody><tr>
                                <td></td>
                            </tr>
                            <tr>
                                <td bgcolor="#66035a">
                                </td>
                            </tr>
                            <tr bgcolor="#EAEAEA"><td><b>terms of use</b></td></tr>
                            <tr bgcolor="#EAEAEA"><td>
                                    1. About user accounts: When registering for an account, you should provide full information about your full name, username, email,... These are not mandatory information, but when available For future risks and losses, we only accept cases where the above information is correctly and completely filled in. Cases filled with missing information or false information will not be resolved. This information will be used as a basis to support settlement.
                                    If you provide any information that is not truthful or inaccurate, or if we have reason to suspect that the information is not truthful or inaccurate, we reserve the right to temporarily suspend time to verify or terminate your use of your Account and to refuse all use of the Service (or any part thereof) at this time or in the future without incurring any liability. any for you.<br>
                                    2. Account password: In the account management section, for an account, the user will have a password. The password used to log in to Modern Bag. If the user forgets his password, he can use his email to retrieve the password. It is the responsibility of the user to protect the password and e-mail by himself, if the password or electronic rental is disclosed in any way, Modern Bag will not be responsible for any loss incurred.<br>
                                    3. Items: With one account can buy many products. If you want large quantity, you can contact us by email gerishongeri@gmail.com.<br>
                                    4. Absolutely do not use any program, tool or other form to interfere with the website or change the structure of the website (hacks, cheats, bots...). Any violations when detected will be handled in accordance with the law.<br>
                                    5. It is strictly forbidden to distribute, propagate or promote any activities to interfere, destroy or infiltrate the data of the service as well as the server system.<br>
                                    6. When you discover an error of the website, please notify us via email gerishongeri@gmail.com.<br>
                                    7. Not to have any acts to illegally log in or attempt to illegally log in as well as cause damage to the server system of the service. All of these acts are considered acts of destruction of other people's property and will deprive the user of all rights and will be prosecuted before the law if necessary.<br>
                                    8. Do not accept the purchase and sale of items or service accounts with real money or in kind on and off the website. In the event the user violates this provision, we do not take any responsibility for the restoration of the item or service. In addition, if we detect violating accounts, we will permanently block them.<br>
                                    9. When communicating with other users, you must not harass, curse, disturb or have any uncultured behavior towards other players.<br>
                                    10. It is absolutely forbidden to insult or ridicule others in any form (mocking, disparaging, discriminating against religion, gender, ethnicity, etc.).<br>
                                    11. It is strictly forbidden to impersonate or intentionally make others think they are another user in the system. Any violations will be handled or account stripped.<br>
                                    12. Modern Bag - we will not be responsible for any system problems when you install and use the service.<br>
                                    13. When detecting violations such as using cheats, hacks, or other errors, Modern Bag has the right to use the information you provide when registering for an account to transfer to the relevant authorities for settlement according to regulations. of the law.<br>
                                    14. In case of force majeure such as electric shock, hardware or software damage, or natural disasters, etc. The user must accept the damages if any.<br>
                                    15. Modern Bag has the full right to delete, correct or change the data, account information in case that person violates the above provisions without the consent of the user.<br>
                                    16. Absolutely prohibit all acts of propagandizing, sabotaging and distorting the government, political institutions, and state policies... In case of detection, not only will our accounts be deleted, but our accounts will be deleted. can also provide that person's information to the authorities for legal handling.<br>
                                </td></tr>
                            <tr>
                                <td bgcolor="#05011c">
                                </td>
                            </tr>
                            <tr>
                                <td style="font-size: x-small">
                                    We sell Quality Bags Worldwide.<br>
                                    This Company Undertakes all Kenyan Goernment Licence Rules and Regulation<br>
                                </td>
                            </tr>
                        </tbody></table>
                </div>
            </div>
        </div>
        <?php include('jsfile.php')?>
    </body>
</html>



















