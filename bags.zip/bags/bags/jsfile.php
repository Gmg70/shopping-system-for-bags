<?php

echo'
        <script src = "js/jquery2.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="main.js"></script>
        <script src="js/jquery.js"></script>
        <script src="js/functions.js"></script>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <!--   <script src="assets/js/bootstrap.min.js"></script>     -->
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/jquery.li-scroller.1.0.js"></script>
        <script src="assets/js/jquery.newsTicker.min.js"></script>
        <script src="assets/js/jquery.fancybox.pack.js"></script>
        <script src="assets/js/custom.js"></script>
        <script src="assets/js/preloader.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/script.js"></script>
        <script src="assets/js/slider.min.js"></script>
        <script src="assets/js/toucheffects.js"></script>
        <script src="assets/js/modernizr.custom.js"></script>
        <script src="assets/js/jquery.elevatezoom.js"></script>
        <script src="assets/js/jquery.zoom.js"></script>
      
'
?>

