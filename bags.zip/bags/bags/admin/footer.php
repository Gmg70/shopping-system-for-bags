  		
  		<footer style="text-align: center;" class="pull-left footer">
  			<p  class="col-md-12">
  				<hr class="divider">
  				Copyright 2017 <a href="#">Mordern Bag</a>
  			</p>
  		</footer>
  	</div>
  <script type="text/javascript" src="dist/js/home_admin.js"></script>

  <script type="text/javascript" src="bower_components/jquery/dist/jquery.min.js"></script>

  <script type="text/javascript" src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script >
    $(document).ready(function(){
    $('#myTable').DataTable();
});
</script>
<script type="text/javascript" src="bower_components/DataTables/media/js/jquery.dataTables.min.js"></script>

</body>
</html>