<?php

echo "<script type='text/javascript'>
	init_reload();
	function init_reload(){
	    setInterval( function() {
	               window.location.reload();
	      },100);
	}
	</script>";
?>

