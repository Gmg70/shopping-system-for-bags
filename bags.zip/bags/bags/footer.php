<?php
echo "<footer id='footer'>
        <div class='footer-bottom'>
            <div class='container'>
                <div class='row'>
                    <div class='col-sm-3'>
                        <aside>
                        <h1 class='contact_footer element_footer'>Company</h1>
                         <address>
                              <h1 class='center test font_thuphap'>This Company deales with bags worldwide.</h1>
                         </address>   
                        </aside>

                    </div>

                    <div class='col-sm-3'>
                        <aside>
                            <h1 class='element_footer fadeIn'>Category</h1>
                            <ul class='category'>
                                <li><a href='' class='category_boder red' ><i class=''></i>Home Page</a></li>
                                <li><a href='' class='category_boder red' ><i class=''></i>Bag</a></li>
                                <li><a href='' class='category_boder red' ><i class=''></i>Back Pack</a></li>
                                <li><a href='' class='category_boder red' ><i class=''></i>Walet</a></li>
                                <li><a href='' class='category_boder red' ><i class=''></i>Promotion</a></li>
                            </ul>
                        </aside>

                    </div>

                    <div class='col-sm-3'>
                        <aside>
                            <h1 class='infor_footer element_footer'> We Are</h1>
                            <a>
                                <img class='logo_footer' alt='' src='images/logo_footer.gif'>    
                            </a>
                        </aside>
                    </div>

                    <div class='col-sm-3'>
                        <aside>
                            <h1 class='contact_footer element_footer'>Contact</h1>
                            <address>
                                <h4 class='center test font_thuphap'>Modern Bags Shop International</h4>
                            </address>
                           
                        </aside>
                    </div>
                </div>
            </div>
        </div>
        <div style='text-align: center; font-size: x-medium'>
            We sell Quality Bags Worldwide.<br>
            
            <br>
        </div>
    </footer>";
?>
